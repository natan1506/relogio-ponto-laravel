<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Recesso extends Model
{
    protected $fillable = [
        'nome',
        'recesso',
      ];
}
